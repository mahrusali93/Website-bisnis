# Website BisnisKami

Ini adalah website sederhana untuk profil bisnis, dengan animasi ringan, halaman portofolio, testimoni, blog, dan tim.

## Halaman

- `index.html` — Halaman utama
- `versi_gambar.html` — Versi dengan gambar background
- `portofolio.html` — Daftar proyek
- `testimoni.html` — Testimoni dari klien
- `blog.html` — Artikel dan tips
- `tim.html` — Profil anggota tim

## Cara Menjalankan

Cukup buka `index.html` di browser, atau deploy ke GitHub Pages / Netlify untuk online.

## Lisensi

Bebas digunakan dan dimodifikasi untuk keperluan pribadi dan bisnis.